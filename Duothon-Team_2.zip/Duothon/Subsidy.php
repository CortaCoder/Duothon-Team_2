<?php
    ini_set("session.cookie_secure",1);
    ini_set("session.use_strict_mode",1);
    ini_set("session.cookie_httponly", 1);
    session_start();
    $data=array();
    $myfile=fopen("subs.csv","r");
    while($row=fgetcsv($myfile,0,";")){
        $data[$row[0]]=$row[1];
    }
    fclose($myfile);
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <header>
            Farmers Central
        </header>
        <div class="navbar">
            <a href="farmers.php"><button class="elm">
                Farmers
            </button></a>
            <a href="crops.php"><button class="elm">
                Crops
            </button></a>
            <a href="land.php"><button class="elm">
                Land
            </button></a>
            <a href="loans.php"><button class="elm">
                Loans
            </button></a>
            <a href="Subsidy.php"><button class="elm1">
                Subsidy
            </button></a>
        </div>
        <div class="main">
            <br>
            <h1>Welcome to the Farmer's Central</h1>
            <p style="font-size: 25px;">
                An easy way to control your fortune<br>
                Subsidies provided to farmers
            </p>
            <br>
            <div id="leadb">
                <table>
                    <tr>
                        <th>Name</th>
                        <th>Subsidy Amount</th>
                    </tr>
                    <?php
                        arsort($data);
                        $i=0;
                        foreach($data as $x => $x_value) {
                            if($i==10)
                                break;
                            echo "<tr>";
                            echo "<td>".$x."</td>";
                            echo "<td>".$x_value."</td>";
                            echo "</tr>";
                            $i++;
                        }
                    ?>
                </table>
            </div>
        </div>
    </body>
</html>