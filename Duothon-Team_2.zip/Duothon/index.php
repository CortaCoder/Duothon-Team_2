<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <header>
            Farmers Central
        </header>
        <div class="navbar">
            <a href="farmers.php"><button class="elm">
                Farmers
            </button></a>
            <a href="crops.php"><button class="elm">
                Crops
            </button></a>
            <a href="land.php"><button class="elm">
                Land
            </button></a>
            <a href="loans.php"><button class="elm">
                Loans
            </button></a>
            <a href="Subsidy.php"><button class="elm">
                Subsidy
            </button></a>
        </div>
        <div class="main">
            <br>
            <h1>Welcome to the Farmer's Central</h1>
            <p style="font-size: 25px;">
                An easy way to control your fortune
            </p>
            <br>
        </div>
    </body>
</html>